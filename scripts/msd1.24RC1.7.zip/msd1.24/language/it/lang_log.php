<?php
$lang['log_delete']="Cancella i log";
$lang['logfileformat']="Formato del file log";
$lang['logfilenotwritable']="Impossibile scrivere il file di log!";
$lang['noreverse']="Il piu vecchio come primo";
$lang['reverse']="Il piu nuovo come primo";


?>