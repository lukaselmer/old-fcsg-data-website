<?php
$lang['restore_tables_completed0']="Finora sono stati create <b>%d</b> tabelle.";
$lang['file_missing']="impossibile trovare il file";
$lang['restore_db']="Database '<b>%s</b>' sul Server '<b>%s</b>'.";
$lang['restore_complete']="<b>%s</b> tabelle sono state create.";
$lang['restore_run1']="<br>Finora sono stati aggiunti con successo da <b>%s</b> a <b>%s</b> record.";
$lang['restore_run2']="<br>Sto popolando la tabella '<b>%s</b>'.<br><br>";
$lang['restore_complete2']="<b>%s</b> record sono stati inseriti.";
$lang['restore_tables_completed']="Finora sono state create da <b>%d</b> a <b>%d</b> tabelle.";
$lang['restore_total_complete']="<br><b>Congratulazioni!</b><br><br>Il database è stato ripristinato completamente.<br>Tutti i file del backup sono stati inseriti con successo.<br><br>Hai finito. :-)";
$lang['db_select_error']="<br>Errore:<br>Selezione del database <b>";
$lang['db_select_error2']="</b> fallito!";
$lang['file_open_error']="Errore: impossibile aprire il file.";
$lang['progress_over_all']="Progresso totale";
$lang['back_to_overview']="Riepilogo database";
$lang['restore_run0']="<br>Finora sono stati aggiunti con successo da <b>%s</b> a <b>%s</b> record.";
$lang['unknown_sqlcommand']="Comando SQL sconosciuto.";
$lang['notices']="Avvisi";


?>