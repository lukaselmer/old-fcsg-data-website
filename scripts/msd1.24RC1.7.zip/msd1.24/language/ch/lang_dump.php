<?php
$lang['dump_headline']="bi am backup mache..";
$lang['gzip_compression']="GZip-Kompression";
$lang['saving_table']="Spichere Tabälle";
$lang['of']="vo";
$lang['actual_table']="Aktuelli Tabälle";
$lang['progress_table']="Fortschritt Tabälle";
$lang['progress_over_all']="Fortschritt gsamt";
$lang['entry']="Itrag";
$lang['done']="Alls gmacht!";
$lang['dump_successful']="isch erfolgriich erstellt worde.";
$lang['upto']="bis";
$lang['email_was_send']="D E-Mail isch erfolriich verschickt worde an";
$lang['back_to_control']="wiiter";
$lang['back_to_overview']="zrugg zur Übersicht";
$lang['dump_filename']="Backup-Datei:";
$lang['withpraefix']="mit Präfix";
$lang['dump_notables']="Es händ kei Tabällen i de Datenbank `<b>%s</b>` chöne gfunde werde.";
$lang['dump_endergebnis']="Es sind <b>%s</b> Tabälle mit zäme <b>%s</b> Datesätz gsicheret worde.<br>";
$lang['mailerror']="Leider isch bim Verschicke vo de E-Mail en Fähler underloffe!";
$lang['emailbody_attach']="Im Aahang finded Si d Sicherig vo Ihrer MySQL-Datenbank.<br>Sicherig vo de Datenbank `%s` <br><br>Folgende Datei wurde erzeugt:<br><br>%s <br><br>Fründlichi Grüess<br><br>MySQLDumper<br>";
$lang['emailbody_mp_noattach']="Es isch e Multipart-Sicherig erstellt worde.<br>Die Sicherige werdet nöd als Aahang mitglieferet!<br>Sicherig vo de Datenbank `%s` <br><br>Folgendi Dateie sind erzügt worde:<br><br>%s<br><br><br>Fründlichi Grüess<br><br>MySQLDumper<br>";
$lang['emailbody_mp_attach']="Es isch e Multipart-Sicherig erstellt worde.<br>D Sicherige werdet i separate E-Mails als Anhang glieferet!<br>Sicherig vo de Datenbank `%s` <br><br>Folgendi Dateie sind erzügt worde:<br><br>%s<br><br><br>Fründlichi Grüess<br><br>MySQLDumper<br>";
$lang['emailbody_footer']="<br><br><br>Fründlichi Grüess<br><br>MySQLDumper<br>";
$lang['emailbody_toobig']="D Sicherig überschriitet d Maximalgrössi von %s und isch drum nöd aagehänkt worde.<br>Sicherig vo de Datenbank `%s` <br><br>Folgendi Datei isch erzügt worde:<br><br>%s <br><br>Fründlichi Grüess<br><br>MySQLDumper<br>";
$lang['emailbody_noattach']="S Backup isch nöd aaghänkt worde.<br>Sicherig vo de Datenbank `%s` <br><br>Folgendi Datei isch erzügt worde:<br><br>%s <br><br>Fründlichi Grüess<br><br>MySQLDumper<br>";
$lang['email_only_attachment']="... nume dr Aahang";
$lang['tableselection']="Tabälleuswahl";
$lang['selectall']="ali uuswähle";
$lang['deselectall']="Uswahl ufhebä";
$lang['startdump']="Backup starte";
$lang['lastbufrom']="sletschti Update vom";
$lang['not_supported']="Das Backup cha diä Funktion nöd.";
$lang['multidump']="Multidump: Es sind <b>%d</b> Datenbanke gesicheret worde.";
$lang['filesendftp']="verschicke grad File via FTP... heb bitte e chli Geduld.";
$lang['ftpconnerror']="FTP-Verbindig nöd hergstellt! Verbindig mit";
$lang['ftpconnerror1']="als User";
$lang['ftpconnerror2']="nöd mögli";
$lang['ftpconnerror3']="FTP-Upload isch fählerhaft gsi!";
$lang['ftpconnected1']="Verbunde mit";
$lang['ftpconnected2']="uf";
$lang['ftpconnected3']="gschribe";
$lang['nr_tables_selected']="- mit %s gewählte Tabälle";
$lang['nr_tables_optimized']="<span class=\"small\">%s Tabälle sind optimiert worde.</span>";
$lang['dump_errors']="<p class=\"error\">%s Fähler ufträte: <a href=\"log.php?r=3\">aaluege</a></p>";
$lang['fatal_error_dump']="Fatale Fähler: d CREATE-Aawiisig vo de Tabelle '%s' i de Datenbank '%s' hät nöd chöne gläse werde! <br> Überprüefed Si die Tabälle auf Fähler.";


?>