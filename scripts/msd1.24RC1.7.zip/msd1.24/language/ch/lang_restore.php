<?php
$lang['restore_tables_completed0']="Es sind bis ez <b>%d</b> Tabälle agleit worde.";
$lang['file_missing']="Han diä Datei nöd gfunde";
$lang['restore_db']="Datebank '<b>%s</b>' uf Server '<b>%s</b>'.";
$lang['restore_complete']="<b>%s</b> Tabälle sind angleit worde.";
$lang['restore_run1']="<br>Es sind bis ez <b>%s</b> vo <b>%s</b> Datesätz erfolgriich iitreit worde.";
$lang['restore_run2']="<br>Momentan werdet Date vo de Tabälle '<b>%s</b>' analysiert.<br><br>";
$lang['restore_complete2']="<b>%s</b> Datesätz sind iitreit worde.";
$lang['restore_tables_completed']="Es sind bis ez <b>%d</b> vo <b>%d</b> Tabälle agleit worde.";
$lang['restore_total_complete']="<br><b>Herzliche Glückwunsch.</b><br><br>Diä Datenbank isch komplett reschtauriert worde.<br>Alli Date us de Backup-Datei sind erfolgriich i diä Datebank itreit worde.<br><br>Alls fertig. :-)";
$lang['db_select_error']="<br>Fähler:<br>Uuswahl vo de Datebank '<b>";
$lang['db_select_error2']="</b>' abverheit!";
$lang['file_open_error']="Fähler: Diä Datei hät nöd chöne ufgmacht wärde";
$lang['progress_over_all']="Fortschritt total";
$lang['back_to_overview']="Datebank-Übersicht";
$lang['restore_run0']="<br>Es sind bis ez <b>%s</b> Datesätz erfolgriich iitreit worde.";
$lang['unknown_sqlcommand']="Unbekannte SQL-Befehl:";
$lang['notices']="Hiiwis";


?>