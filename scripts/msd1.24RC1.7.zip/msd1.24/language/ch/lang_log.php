<?php
$lang['log_delete']="Log lösche";
$lang['logfileformat']="Log-Dateiformat";
$lang['logfilenotwritable']="Log-Datei cha nöd gschribe wärde!";
$lang['noreverse']="ältischte Iitrag zerscht";
$lang['reverse']="neuschte Iitrag zerscht";


?>