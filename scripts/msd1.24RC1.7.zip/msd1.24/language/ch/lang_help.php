<?php
$lang['help_db']="Das isch d Lischte vo de vorhandene Datebanke.";
$lang['help_praefix']="Dr Präfix isch e Zeichefolg für d Aafang vo Tabälle, wo als Filter fungiert.";
$lang['help_zip']="Kompression mit GZip - emfohle isch 'aktiviert'.";
$lang['help_memorylimit']="Das isch di maximali Grössi i Bytes, wo das Skript a Speicher überchunnt. 0 = deaktiviert";
$lang['memory_limit']="Spiichergränze";
$lang['help_ad1']="Wänn aktiviert, dänn werdet automatisch Backup-Dateie glöscht.";
$lang['help_ad3']="Di maximali Aazahl vo Dateie, wo im Backup-Verzeichnis sii dörfed (für Autodelete). 0 = deaktiviert";
$lang['help_lang']="Stellt uf di gwünschti Sprach.";
$lang['help_empty_db_before_restore']="Zum überflüssigi Date eliminiere, cha me anwiise, d Datebank vor de Reschtaurierig komplett z lääre.";
$lang['help_cronextender']="D Endig vom Perlscript, Standard isch '.pl'.";
$lang['help_cronprintout']="Wänn d Textuusgab abgschaltet isch, wird kei Text meh ausgeh. Diä Funktion isch unabhängig vo de Log-Uusgab.";
$lang['help_crondbindex']="Wähl d Datebank für de Cronjob";
$lang['help_ftptransfer']="Wänn aktiviert, wird nachem Backup diä Datei per FTP gschickt.";
$lang['help_ftpserver']="D Adrässe vom FTP-Server.";
$lang['help_ftpport']="Port vom FTP-Server. Standard: 21";
$lang['help_ftpuser']="Gib de Benutzername vo de FTP-Verbindig a.";
$lang['help_ftppass']="Gibs s Passwort vo de FTP-Verbindig a.";
$lang['help_ftpdir']="Wohäre söll diä Datei gschickt wärde?";
$lang['help_speed']="Minimali und maximali Gschwindigkeit. Standard isch 50 bis 5000. (Z höchi Gschwindigkeite chönned zu Timeouts führe!)";
$lang['speed']="Gschwindigkeitskontrolle";
$lang['help_cronexecpath']="Dr Ort, wo die Perlskripts ligged. Usgangspunkt isch d HTTP-Adresse (also im Browser). Erlaubt sind absoluti und relativi Pfadaagabe.";
$lang['cron_execpath']="Pfad vo de Perlskripts";
$lang['help_croncompletelog']="Wänn diä Funktion aktiviert isch, wird di kompletti Usgab im complete_log gschribe. Diä Funtion isch unabhängig vo de Textusgab.";
$lang['help_ftp_mode']="Wänn Problem bi de FTP-Überträgig uftauched, versueched Si de passivi FTP-Modus";


?>