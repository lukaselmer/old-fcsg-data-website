<?php
$lang['restore_tables_completed0']="Up to now <b>%d</b> tables were created.";
$lang['file_missing']="Bestand kon niet worden gevonden";
$lang['restore_db']="Database '<b>%s</b>' op de Sever '<b>%s</b>'.";
$lang['restore_complete']="<b>%s</b> Tabellen zijn aangemaakt.";
$lang['restore_run1']="<br>Up to now  <b>%s</b> of <b>%s</b> records were successfully added.";
$lang['restore_run2']="<br>Now the table '<b>%s</b>' is restoring.<br><br>";
$lang['restore_complete2']="<b>%s</b> Database-entries zijn aangemaakt.";
$lang['restore_tables_completed']="Up to now <b>%d</b> of <b>%d</b> tables were created.";
$lang['restore_total_complete']="<br><b>Congratulations.</b><br><br>The restoration of the database is done.<br>All data from the Backup file was restored.<br><br>Everything is done. :-)";
$lang['db_select_error']="<br>Fout:<br>Keuze van de Database '<b>";
$lang['db_select_error2']="</b>' mislukt!";
$lang['file_open_error']="Fout: De bestand kon niet worden geopend.";
$lang['progress_over_all']="Process totaal";
$lang['back_to_overview']="Database overzicht";
$lang['restore_run0']="<br>Er zijn tot nu toe <b>%s</b> Database-entries succesvol ingeschreven.";
$lang['unknown_sqlcommand']="onbekend SQL-Bevel";
$lang['notices']="Notices";


?>