<?php
$lang['log_delete']="Log verwijderen";
$lang['logfileformat']="Log-bestandsformaat";
$lang['logfilenotwritable']="Log-bestand kan niet worden geschreven";
$lang['noreverse']="oudste log eerst";
$lang['reverse']="nieuwste log eerst";


?>