<?php
$lang['restore_tables_completed0']="Es wurden bisher <b>%d</b> Tabellen angelegt.";
$lang['file_missing']="konnte Datei nicht finden";
$lang['restore_db']="Datenbank '<b>%s</b>' auf Server '<b>%s</b>'.";
$lang['restore_complete']="<b>%s</b> Tabellen wurden angelegt.";
$lang['restore_run1']="<br>Es wurden bisher <b>%s</b> von <b>%s</b> Datensätzen erfolgreich eingetragen.";
$lang['restore_run2']="<br>Momentan werden Daten der Tabelle '<b>%s</b>' analysiert.<br><br>";
$lang['restore_complete2']="<b>%s</b> Datensätze wurden eingetragen.";
$lang['restore_tables_completed']="Es wurden bisher <b>%d</b> von <b>%d</b> Tabellen angelegt.";
$lang['restore_total_complete']="<br><b>Herzlichen Glückwunsch.</b><br><br>Die Datenbank wurde komplett wiederhergestellt.<br>Alle Daten aus der Backup-Datei wurden erfolgreich in die Datenbank eingetragen.<br><br>Alles fertig. :-)";
$lang['db_select_error']="<br>Fehler:<br>Auswahl der Datenbank '<b>";
$lang['db_select_error2']="</b>' fehlgeschlagen!";
$lang['file_open_error']="Fehler: Die Datei konnte nicht geöffnet werden.";
$lang['progress_over_all']="Fortschritt gesamt";
$lang['back_to_overview']="Datenbank-Übersicht";
$lang['restore_run0']="<br>Es wurden bisher <b>%s</b> Datensätze erfolgreich eingetragen.";
$lang['unknown_sqlcommand']="Unbekannter SQL-Befehl:";
$lang['notices']="Hinweise";


?>