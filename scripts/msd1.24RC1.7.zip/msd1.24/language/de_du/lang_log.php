<?php
$lang['log_delete']="Log löschen";
$lang['logfileformat']="Log-Dateiformat";
$lang['logfilenotwritable']="Log-Datei kann nicht geschrieben werden!";
$lang['noreverse']="Ältester Eintrag zuerst";
$lang['reverse']="Neuster Eintrag zuerst";


?>