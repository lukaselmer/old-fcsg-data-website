<?php
$lang['log_delete']="slet Log";
$lang['logfileformat']="Logfilformat";
$lang['logfilenotwritable']="Kan <b>ikke</b> skrive Logfil!";
$lang['noreverse']="Ældste indlæg først";
$lang['reverse']="Seneste indlæg først


";


?>