<?php
$lang['restore_tables_completed0']="Hasta el momento, se han recuperado <b>%d</b> tablas.";
$lang['file_missing']="no se encuentra el fichero";
$lang['restore_db']="la base de datos '<b>%s</b>' en '<b>%s</b>'.";
$lang['restore_complete']="<b>%s</b> Las tablas han sido importadas.";
$lang['restore_run1']="<br>Hasta ahora se han importado <b>%s</b> de <b>%s</b> registros";
$lang['restore_run2']="<br/>Se está llenando de datos la tabla '<b>%s</b>'.<br/><br/>";
$lang['restore_complete2']="<b>%s</b> registros insertados.";
$lang['restore_tables_completed']="Hasta el momento, se han recuperado <b>%d</b> de <b>%d</b> tablas.";
$lang['restore_total_complete']="<br><b>Felicidades.</b><br><br>La base de datos ha sido completamente restaurada.<br>Todos los datos de la copia de seguridad han sido importados con éxito.<br><br>He terminado. :-)";
$lang['db_select_error']="<br>Error:<br>La selección de la base de datos '<b>";
$lang['db_select_error2']="</b>' ha fallado!";
$lang['file_open_error']="Error: no he podido abrir el fichero.";
$lang['progress_over_all']="Progreso total";
$lang['back_to_overview']="vista de base de datos";
$lang['restore_run0']="Hasta el momento, se han recuperado <b>%s</b> de tablas.";
$lang['unknown_sqlcommand']="comando SQL desconocido";
$lang['notices']="Avisos";


?>