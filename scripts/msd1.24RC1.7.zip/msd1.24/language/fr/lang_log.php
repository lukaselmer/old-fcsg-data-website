<?php
$lang['log_delete']="Supprimer le journal";
$lang['logfileformat']="Format du journal";
$lang['logfilenotwritable']="Écriture du Journal impossible!";
$lang['noreverse']="Montrer les entrées les plus anciennes en premier";
$lang['reverse']="Montrer les entrées les plus récentes en premier";


?>