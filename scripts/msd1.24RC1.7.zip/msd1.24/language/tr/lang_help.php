<?php
$lang['help_db']="Veritabanlarının listesi";
$lang['help_praefix']="Tablo ön eki, tabloların daha kolay filtrelenebilmesini sağlamak için tablo isimlerinin önüne eklenir.";
$lang['help_zip']="GZip ile sıkıştırma - etkin olması önerilir'";
$lang['help_memorylimit']="Byte olarak belirlenir, Scriptin kullanabileceği azami hafızayı belirler
0 = Devre dışı";
$lang['memory_limit']="Hafıza sınırı";
$lang['help_ad1']="Aktiv olduğunda yedekleme dosyaları otomatik olarak silinir.";
$lang['help_ad3']="Yedekleme dosyalarının maximum sayısı (Otomatik silme için)
0 = kullanılmaz";
$lang['help_lang']="Dil seçeneği";
$lang['help_empty_db_before_restore']="Gereksiz kayıtların silinmesi için, geri dönüıümden önce Veritabanlarının boşaltılmasını sağlayabilirsiniz.";
$lang['help_cronextender']="Perlscriptinin dosyabitimi, Standard: '.pl'.";
$lang['help_cronprintout']="Yazı çıktısı kapalı olursa, sonuçlar belirtilmez.
Bu fonksiyon rapor dosyasına bağlı değildir.";
$lang['help_crondbindex']="Cronscript için kullanılacak Veritabanını seçiniz.";
$lang['help_ftptransfer']="Seçildiğinde yedekleme den sonra dosya FTP ile gönderilir.";
$lang['help_ftpserver']="FTP-Sunucusunun adresi.";
$lang['help_ftpport']="FTP-Sunucusunun Portnumarası, Standart: 21.";
$lang['help_ftpuser']="FTP-Kullanıcısının adı";
$lang['help_ftppass']="FTP-Kullanıcısının şifresi.";
$lang['help_ftpdir']="Dosyanın gönderileceği yer?";
$lang['help_speed']="en düşük ve en yüksek hız, standart: 50'den 5000'e kadar
(daha yüksek hız ayarı çalışmayabilir!).";
$lang['speed']="Hız";
$lang['help_cronexecpath']="Perlskriptin bulunduğu alan.
HTTP-Adressinden yola çıkarak (Tarayıcıda).";
$lang['cron_execpath']="Perlskript'in veriyolu";
$lang['help_croncompletelog']="Aktiv olması durumunda çıktının komplesi complete_log dosyasına kaydedilir. 
Textçıktısı ayarlarına bağlı değildir.";
$lang['help_ftp_mode']="Eğer FTP-Transfer esnasında hata oluşursa,lütfen Pasif-Modus yöntemi ile deneyin.";


?>