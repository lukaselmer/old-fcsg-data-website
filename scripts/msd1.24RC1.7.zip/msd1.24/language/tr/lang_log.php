<?php
$lang['log_delete']="Raporu sil";
$lang['logfileformat']="Rapor dosyasının biçimi";
$lang['logfilenotwritable']="Rapor dosyasına yazılamıyor!";
$lang['noreverse']="Eski kayıtlar önce";
$lang['reverse']="Yeni kayıtlar önce";


?>