<?php
$lang['help_db']="Đây là danh sách (của) tất cả các cơ sở dữ liệu";
$lang['help_praefix']="tiền tố là một chuỗi ký tự bắt đầu cho một tên bảng, nó làm việc  như một bộ lọc.";
$lang['help_zip']="Nén với GZip - nên 'kích hoạt'";
$lang['help_memorylimit']="Số lượng tối đã (tính bằng Byte) cho script
0 = ngưng kích hoạt";
$lang['memory_limit']="Giới hạn bộ nhớ";
$lang['help_ad1']="Nếu được kích hoạt, file sao lưu sẽ được tự động xóa.";
$lang['help_ad3']="số lượng file sao lưu tối đa (sẽ bị xóa tự động)
0 = không khống chế";
$lang['help_lang']="select your language";
$lang['help_empty_db_before_restore']="Để loại trừ dữ liệu vô ích bạn có thể chỉ dẫn làm trống rỗng cơ sở dữ liệu trước khi khôi phục";
$lang['help_cronextender']="Phần mở rộng của mã nguồn Perl, mặc định là '.pl'";
$lang['help_cronprintout']="Nếu ngưng kích hoạt, kết quả sẽ không xxược in ra màn hình.
Nó độc lập với việc in trong logfile.";
$lang['help_crondbindex']="choose the database for Cron job";
$lang['help_ftptransfer']="nếu kích hoạt, file sẽ được gửi qua FTP.";
$lang['help_ftpserver']="Địa chỉ của FTP-Server";
$lang['help_ftpport']="Cổng của FTP-Server, chuẩn là: 21";
$lang['help_ftpuser']="nhập username truy cập FTP";
$lang['help_ftppass']="nhập mật khẩu truy cập FTP";
$lang['help_ftpdir']="thư mục upload ở đâu? nhập đường dẫn!";
$lang['help_speed']="Tốc độ tối thiểu và tối đa, mặc định là 50 tới 5000";
$lang['speed']="Điều khiển tốc độ";
$lang['help_cronexecpath']="Nơi của Perl scripts.
Xuất phát từ HTTP-Address (giống địa chỉ ở trình duyệt)
được sử dụng địa chỉ tuyệt đối hay tương đối.";
$lang['cron_execpath']="Đường dẫn của Perl scripts";
$lang['help_croncompletelog']="Khi được kích hoạt, đường ra đầy đủ được ghi trong complete_log-file.
Cái này độc lập với văn bản đang in";
$lang['help_ftp_mode']="Khi có vấn đề xuất hiện với việc chuyển qua FTP, thử sử dụng chế độ bị động (passive mode).


";


?>