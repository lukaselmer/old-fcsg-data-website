<?php
$lang['restore_tables_completed0']="Cho tới giờ, <b>%d</b> bảng đã được tạo ra.";
$lang['file_missing']="không tìm thấy file";
$lang['restore_db']="'<b>%s</b>' CSDL trong '<b>%s</b>'.";
$lang['restore_complete']="<b>%s</b> bảng đã được tạo ra.";
$lang['restore_run1']="<br>Tính đến giờ, <b>%s</b> trong số <b>%s</b> bản ghi đã được thêm vào thành công.";
$lang['restore_run2']="<br>Hiện tại bảng '<b>%s</b>' đang được phục hồi.<br><br>";
$lang['restore_complete2']="<b>%s</b> bản ghi được chèn vào.";
$lang['restore_tables_completed']="Tính đến giờ, <b>%d</b> trong số <b>%d</b> table đã được tạo.";
$lang['restore_total_complete']="<br><b>Chúc mừng.</b><br><br>Việc phục hồi cơ sở dữ liệu đã xong.<br>Tất cả dữ liệu Sao lưu đã được phục hồi.<br><br>Mọi việc đã kết thúc. :-)";
$lang['db_select_error']="<br>Lỗi:<br>Lựa chọn CSDL <b>";
$lang['db_select_error2']="</b> thất bại!";
$lang['file_open_error']="Lỗi: Không thể mở file.";
$lang['progress_over_all']="Toàn bộ tiến trình";
$lang['back_to_overview']="Tổng quan Cơ sở dữ liệu";
$lang['restore_run0']="<br>Tính đến giờ, <b>%s</b> bản ghi đã được thêm vào thành công.";
$lang['unknown_sqlcommand']="không hiểu lệnh SQL";
$lang['notices']="Chú ý


";


?>