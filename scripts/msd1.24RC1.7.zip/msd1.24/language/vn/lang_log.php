<?php
$lang['log_delete']="xóa Log";
$lang['logfileformat']="Định dạng file nhật ký (logfile)";
$lang['logfilenotwritable']="Không thể ghi file nhật ký Logfile !";
$lang['noreverse']="Cũ lên trên";
$lang['reverse']="Mới lên trên


";


?>