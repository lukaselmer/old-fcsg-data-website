<?php
$lang['log_delete']="Log löschen";
$lang['logfileformat']="Logfileformat";
$lang['logfilenotwritable']="Log-File kann nicht geschrieben werden!";
$lang['noreverse']="ältester Eintrag zuerst";
$lang['reverse']="neuster Eintrag zuerst";


?>