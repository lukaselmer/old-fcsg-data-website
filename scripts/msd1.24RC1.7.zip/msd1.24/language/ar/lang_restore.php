<?php
$lang['restore_tables_completed0']="البدء لآن <b>%d</b> تم انشاء الجداول.";
$lang['file_missing']="لا يستطيع ايجاد الملف";
$lang['restore_db']="قاعدة البيانات '<b>%s</b>' على '<b>%s</b>'.";
$lang['restore_complete']="<b>%s</b> انشاء الجداول.";
$lang['restore_run1']="<br>البدء لآن  <b>%s</b> of <b>%s</b> تمت الاضافة بنجاح.";
$lang['restore_run2']="<br>ابدأ الجداول  '<b>%s</b>'اعادة.<br><br>";
$lang['restore_complete2']="<b>%s</b> ادراج سجلات.";
$lang['restore_tables_completed']="البدء لآن <b>%d</b> of <b>%d</b> تم انشاء الجداول.";
$lang['restore_total_complete']="<br><b>تهانينا.</b><br><br>تمت الان استعادة قاعدة البيانات.<br>تم استعادة جميع ملفات النسخ الاحتياطي.<br><br>انتهت العملية. :-)";
$lang['db_select_error']="<br>مشكلة:<br>حدد قاعدة البيانات <b>";
$lang['db_select_error2']="</b> فشل!";
$lang['file_open_error']="خطأ: لا يمكن فتح الملف.";
$lang['progress_over_all']="التقدم الشامل";
$lang['back_to_overview']="تفاصيل عامة لقاعدة البيانات";
$lang['restore_run0']="<br>البدء لآن<b>%s</b> تمت اضافة السجلات بنجاح.";
$lang['unknown_sqlcommand']="مجهول SQL-امر";
$lang['notices']="ملاحظات

";


?>