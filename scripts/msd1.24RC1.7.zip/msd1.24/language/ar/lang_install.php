<?php
$lang['installfinished']="<br>تم اكتمال التركيب  --> <a href=\"index.php\">ابدأ MySQLDumper</a><br>";
$lang['install_tomenu']="عوده الى القائمة الرئيسة";
$lang['installmenu']="القائمة الرئيسة";
$lang['step']="خطوة ";
$lang['install']="التركيب";
$lang['uninstall']="مسح";
$lang['tools']="الادوات";
$lang['editconf']="تعديل الدليل";
$lang['osweiter']="مواصلة بدون حفظ";
$lang['errorman']="<strong>خطأ اثناء عملية حفظ البيانات!</strong><br>الرجاء تعديل الملف ";
$lang['manuell']="يدوي";
$lang['createdirs']="انشاء الادلة";
$lang['install_continue']="استمر بعملية التركيب";
$lang['connecttomysql']="ربط الى MySQL ";
$lang['dbparameter']="قاعدة البيانات Parameters";
$lang['confignotwritable']="لا يمكن الكتابة للملف \"config.php\".
الرجاء استخدام برامج بروتوكول نقل الملفات الخاصة بك واعط الملف التصريح0777.";
$lang['dbconnection']="الاتصال بقاعدة البيانات";
$lang['connectionerror']="خطأ غير قادر على الربط.";
$lang['connection_ok']="تم تأسيس الاتصال بقاعدة البيانات.";
$lang['saveandcontinue']="حفظ ومتابعة التركيب";
$lang['confbasic']="اساسي Parameter";
$lang['install_step2finished']="تم الوصول الى قاعدة البيانات بنجاح.";
$lang['install_step2_1']="متابعة التركيب بالإعدادات الافتراضية";
$lang['laststep']="انتهى التركيب";
$lang['ftpmode']="انشاء ادلة ضرورية في النمط الآمن";
$lang['idomanual']="انشاء الدليل الخاص بي";
$lang['dofrom']="بداية من";
$lang['ftpmode2']="تهيئة  مع بروتوكول نقل الملفات FTP:";
$lang['connect']="ربط";
$lang['dirs_created']="انشاء الادلة بشكل صحيح.";
$lang['connect_to']="ربط الى";
$lang['changedir']="تغيير مياشر";
$lang['changedirerror']=" لا يمكن التغيير مباشرة ";
$lang['ftp_ok']="FTPيفضل برتكول ";
$lang['createdirs2']="انشاء الادلة";
$lang['ftp_notconnected']="FTP لم يتم انشاء برتكول نقل الملفات!";
$lang['connwith']="اتصال مع";
$lang['asuser']="اسم المستخدم";
$lang['notpossible']="غير ممكن";
$lang['dircr1']="انشاء في دليل العمل";
$lang['dircr2']="انشاء في دليل الاسناد";
$lang['dircr4']="انشاء في السجل";
$lang['dircr5']="انشاء في  configurationdir";
$lang['indir']="الآن في ";
$lang['check']="فحص الادلة";
$lang['disabledfunctions']="الوظائف المعطلة";
$lang['noftppossible']="لا يجد لديك وظائف بروتوكول نقل الملفات FTP  !";
$lang['nogzpossible']="لا يوجد لديك وظائف ضغط الملفات  !";
$lang['ui1']="جميع أدلة العمل التي يمكن أن تحتوي النسخ الاحتياطي سيتم حذفها.";
$lang['ui2']="هل انت موافق على عمل ذلك?";
$lang['ui3']="لا, الغاء العملية";
$lang['ui4']="نعم ، من فضلك تابع";
$lang['ui5']="حذف ادلة العمل";
$lang['ui6']="تم حذف الجميع بنجاح.";
$lang['ui7']="رجاء احذف الدليل من المخطوطه";
$lang['ui8']="المستوى الاول الاعلى";
$lang['ui9']="حدث خطأ ، لم يكن من الممكن الحذف</p>خطأ بالدليل";
$lang['config_save_error']="<strong>خطأ: </strong>كانت هناك مشكلة في الكتابة الى config.php";
$lang['install_help_port']="(empty = Default Port)";
$lang['install_help_socket']="(empty = Default Socket)";
$lang['tryagain']="حاول مرة اخرى";
$lang['socket']="توصيل";
$lang['port']="منفذ";
$lang['found_db']="العثور على قاعدة بيانات";
$lang['fm_fileupload']="رفع ملف";
$lang['pass']="كلمة المرور";
$lang['no_db_found_info']="تم الاتصال بقاعدة البيانات بنجاح.<br>
تم قبول بيانات المستخدم الخصة بك لـ MySQL-Server.<br>
لم يستطيع العثور على اية قاعدة بيانات.<br>
البحث التلقائي لا يمكن من قبل الخادم.<br>
انت يجب أن تدخل اسم قاعدة البيانات يدويا بعد الانتهاء من التركيب.
اضغط هنا \"configuration\" \"Connection Parameter - display\" وتدخل اسم قاعدة البيانات هناك.

";
$lang['safemodedesc']="السبب PHP يعمل في الوضع الآمن فأنت تحتاج لإنشاء الادلة التالية يدويا بأستخدام برامج نقل الملفات  FTP-Programms:


";


?>