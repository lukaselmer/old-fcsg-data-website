<?php
$lang['log_delete']="حذف مدخلات السجل";
$lang['logfileformat']="تفاصيل الملف في السجل";
$lang['logfilenotwritable']="لا يمكن الكتابة الى ملف السجل !";
$lang['noreverse']="بيانات الدخول الاقدم";
$lang['reverse']="بيانات الدخول الاخيره

";


?>