<?php
$lang['restore_tables_completed0']="Up to now <b>%d</b> tables were created.";
$lang['file_missing']="couldn't find file";
$lang['restore_db']="Database '<b>%s</b>' on '<b>%s</b>'.";
$lang['restore_complete']="<b>%s</b> tables created.";
$lang['restore_run1']="<br>Up to now  <b>%s</b> of <b>%s</b> records were successfully added.";
$lang['restore_run2']="<br>Now the table '<b>%s</b>' is restoring.<br><br>";
$lang['restore_complete2']="<b>%s</b> records inserted.";
$lang['restore_tables_completed']="Up to now <b>%d</b> of <b>%d</b> tables were created.";
$lang['restore_total_complete']="<br><b>Congratulations.</b><br><br>The restoration of the database is done.<br>All data from the Backup file was restored.<br><br>Everything is done. :-)";
$lang['db_select_error']="<br>Error:<br>Selection of database <b>";
$lang['db_select_error2']="</b> failed!";
$lang['file_open_error']="Error: could not open file.";
$lang['progress_over_all']="Overall Progress";
$lang['back_to_overview']="Database Overview";
$lang['restore_run0']="<br>up to now <b>%s</b> records were successfully added.";
$lang['unknown_sqlcommand']="unknown SQL-Command";
$lang['notices']="Notices";


?>