<?php
$lang['log_delete']="delete Log";
$lang['logfileformat']="Logfileformat";
$lang['logfilenotwritable']="Can't! write Logfile !";
$lang['noreverse']="Oldest entry first";
$lang['reverse']="Last entry first";


?>