<?php
$lang['noftppossible']="You don't have FTP functions !";
$lang['info_location']="Your location is ";
$lang['info_databases']="The following database(s) are on your server:";
$lang['info_nodb']="database does not exist.";
$lang['info_table1']="Table";
$lang['info_table2']="s";
$lang['info_dbdetail']="Detailed info of database ";
$lang['info_dbempty']="The database is empty !";
$lang['info_records']="Records";
$lang['info_size']="Size";
$lang['info_lastupdate']="Last update";
$lang['info_sum']="total";
$lang['info_optimized']="optimized";
$lang['optimize_databases']="Optimize Tables";
$lang['check_tables']="Check Tables";
$lang['clear_database']="Clear database";
$lang['delete_database']="Delete database";
$lang['info_cleared']="was cleared";
$lang['info_deleted']="was deleted";
$lang['info_emptydb1']="Should the Database";
$lang['info_emptydb2']=" be truncated? (Attention: All Data will be lost forever!)";
$lang['info_killdb']=" be deleted? (Attention: All Data will be lost forever!)";
$lang['processkill1']="The script tries to kill process ";
$lang['processkill2']="to kill.";
$lang['processkill3']="The script tries since  ";
$lang['processkill4']=" sec. to kill the process ";
$lang['htaccess1']="Create directory protection";
$lang['htaccess2']="Password:";
$lang['htaccess3']="Password (repeat):";
$lang['htaccess4']="Kind of encrypting:";
$lang['htaccess5']="Crypt (Linux and Unix-Systems)";
$lang['htaccess6']="Linux and Unix-Systems (MD5)";
$lang['htaccess7']="plain text, no cryption (Windows)";
$lang['htaccess8']="It already exists an directory protection. If you create a new one, the older one will be overwritten !";
$lang['htaccess9']="You have to enter a name !<br>";
$lang['htaccess10']="The Passwords are not identical or empty !<br>";
$lang['htaccess11']="Should the directory protection be written now ?";
$lang['htaccess12']="The directory protection was created.";
$lang['htaccess13']="Contents of file:";
$lang['htaccess14']="There was an error while creating the directory protection !<br>Please create the 2 files manually with following content:";
$lang['htaccess15']="Urgently recommended !";
$lang['htaccess16']="Edit .htaccess";
$lang['htaccess18']="Create .htaccess in ";
$lang['htaccess19']="Reload ";
$lang['htaccess20']="Execute script";
$lang['htaccess21']="Add handler";
$lang['htaccess22']="Make executable";
$lang['htaccess23']="Directory Listing";
$lang['htaccess24']="Error Document";
$lang['htaccess25']="Activate rewrite";
$lang['htaccess26']="Deny / Allow";
$lang['htaccess27']="Redirect";
$lang['htaccess28']="Error Log";
$lang['htaccess29']="More examples and documentation";
$lang['htaccess30']="Provider";
$lang['htaccess31']="General";
$lang['htaccess32']="Attention! The .htaccess directly affects the browser's behavior.<br>With incorrect content, these pages may no longer be accessible.";
$lang['phpbug']="Bug in zlib ! No Compression possible";
$lang['disabledfunctions']="Disabled Functions";
$lang['nogzpossible']="Because Zlib is not installed, you cannot use GZip-Functions.";
$lang['delete_htaccess']="Remove directory protection (delete .htaccess)";
$lang['wrong_rights']="The file or the directory '%s' is not writable for me.<br>
The rights (chmod) are not set properly or it has the wrong owner.<br>
Pleae set the correct attributes using your FTP-Programm.<br>
The file or the directory needs to be set to %s.<br>";
$lang['cant_create_dir']="Couldn' t create dir '%s'. 
Please create it using your FTP-Programm.";
$lang['table_type']="Type";


?>