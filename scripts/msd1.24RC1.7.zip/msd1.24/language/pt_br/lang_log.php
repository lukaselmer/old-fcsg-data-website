<?php
$lang['log_delete']="excluir log";
$lang['logfileformat']="Formato do arquivo de log";
$lang['logfilenotwritable']="Não pude escrever no arquiuvo de log !";
$lang['noreverse']="Entradas mais antigas primeiro";
$lang['reverse']="Últimas entradas primeiro";


?>