<?php
$lang['restore_tables_completed0']="μέχρι τώρα δημιουργήθηκαν <b>%d</b> πίνακες.";
$lang['file_missing']="δε βρέθηκε το αρχείο";
$lang['restore_db']="Β.Δεδομένων '<b>%s</b>' σε '<b>%s</b>'.";
$lang['restore_complete']="<b>%s</b> πίνακες δημιουργήθηκαν.";
$lang['restore_run1']="<br>Μέχρι τώρα  <b>%s</b> από <b>%s</b> εγγραφές έχουν προστεθεί.";
$lang['restore_run2']="<br>Τώρα ο πίνακας '<b>%s</b>' επαναφέρεται.<br><br>";
$lang['restore_complete2']="<b>%s</b> εγγραφές έχουν εισαχθεί.";
$lang['restore_tables_completed']="Μέχρι τώρα <b>%d</b> από <b>%d</b> πίνακες δημιουργήθηκαν.";
$lang['restore_total_complete']="<br><b>Συγχαρητήρια.</b><br><br>Εγινε η επαναφορά της Β.Δεδομένων.<br>Ολα τα δεδομένα απο το Αντίγραφο Ασφαλείας έχουν επαναφερθεί.<br><br>Ολα ολοκληρώθηκαν. :-)";
$lang['db_select_error']="<br>Σφάλμα:<br>Επιλογή Β.Δεδομένων <b>";
$lang['db_select_error2']="</b> απέτυχε!";
$lang['file_open_error']="Σφάλμα: δεν μπόρεσα να ανοίξω το αρχείο.";
$lang['progress_over_all']="Γενική πρόοδος";
$lang['back_to_overview']="Προεπισκόπιση Β.Δεδομένων";
$lang['restore_run0']="<br>Μέχρι τώρα <b>%s</b> εγγραφές έχουν προστεθεί.";
$lang['unknown_sqlcommand']="Αγνωστη εντολή SQL";
$lang['notices']="Σημειώσεις


";


?>