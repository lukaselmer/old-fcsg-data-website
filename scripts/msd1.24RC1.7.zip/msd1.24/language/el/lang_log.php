<?php
$lang['log_delete']="διαγραφή καταγραφής";
$lang['logfileformat']="μορφή αρχείου καταγραφής";
$lang['logfilenotwritable']="Δε μπορώ να γράψω σε αρχείο καταγραφής !";
$lang['noreverse']="Πρώτα παλιές εγγραφές";
$lang['reverse']="Πρώτα τελευταίες εγγραφές

";


?>